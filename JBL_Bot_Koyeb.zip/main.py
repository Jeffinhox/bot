import os
import asyncio
import yt_dlp
import discord
from discord.ext import commands

# ====== CONFIG ======
TOKEN = os.getenv("DISCORD_TOKEN")
PREFIX = "!"
intents = discord.Intents.default()
intents.message_content = True
intents.voice_states = True

bot = commands.Bot(command_prefix=PREFIX, intents=intents, help_command=None)

# ====== GLOBALS ======
queues = {}             # guild_id -> list of (url, title)
volume = {}             # guild_id -> float (0.0 - 1.0)

ydl_opts = {
    "format": "bestaudio/best",
    "quiet": True,
    "default_search": "ytsearch",
    "noplaylist": True,
    "extract_flat": "in_playlist"
}

ffmpeg_before_opts = "-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5"
ffmpeg_options = "-vn"

ytdl = yt_dlp.YoutubeDL(ydl_opts)

def yt_search(query):
    """Return (stream_url, title) for a query or URL using yt-dlp"""
    info = ytdl.extract_info(query, download=False)
    if "entries" in info:
        info = info["entries"][0]
    url = info.get("url")
    title = info.get("title", "Unknown title")
    return url, title

async def ensure_voice(ctx):
    if ctx.voice_client is None:
        if ctx.author.voice is None or ctx.author.voice.channel is None:
            await ctx.send("❌ Você precisa estar em um canal de voz.")
            return False
        await ctx.author.voice.channel.connect()
    return True

def get_volume(guild_id):
    return volume.get(guild_id, 0.5)

async def play_next(ctx):
    guild_id = ctx.guild.id
    vc = ctx.voice_client
    if not vc or not vc.is_connected():
        return
    if guild_id not in queues or len(queues[guild_id]) == 0:
        try:
            await vc.disconnect()
        except:
            pass
        await ctx.send("✅ Fila finalizada. Sai do canal de voz.")
        return

    url, title = queues[guild_id].pop(0)
    source = discord.FFmpegPCMAudio(url,
                                   before_options=ffmpeg_before_opts,
                                   options=ffmpeg_options)
    player = discord.PCMVolumeTransformer(source, volume=get_volume(guild_id))
    def after_play(err):
        # schedule next in event loop
        fut = asyncio.run_coroutine_threadsafe(play_next(ctx), bot.loop)
        try:
            fut.result()
        except Exception:
            pass
    vc.play(player, after=after_play)
    await ctx.send(f"▶️ Tocando agora: **{title}**")

# ====== COMMANDS ======
@bot.event
async def on_ready():
    print(f"✅ JBL Bot online como {bot.user}")

@bot.command(name="entrar")
async def cmd_entrar(ctx):
    if ctx.author.voice and ctx.author.voice.channel:
        await ctx.author.voice.channel.connect()
        await ctx.send("🎧 Entrei no canal de voz!")
    else:
        await ctx.send("❌ Você precisa estar em um canal de voz.")

@bot.command(name="sair")
async def cmd_sair(ctx):
    if ctx.voice_client:
        await ctx.voice_client.disconnect()
        queues.pop(ctx.guild.id, None)
        volume.pop(ctx.guild.id, None)
        await ctx.send("👋 Saí do canal e limpei a fila!")
    else:
        await ctx.send("❌ Não estou em um canal de voz.")

@bot.command(name="tocar")
async def cmd_tocar(ctx, *, query: str):
    if not await ensure_voice(ctx):
        return
    guild_id = ctx.guild.id
    if guild_id not in queues:
        queues[guild_id] = []
    # search
    await ctx.send(f"🔎 Procurando: **{query}**")
    try:
        url, title = yt_search(query)
    except Exception as e:
        await ctx.send("❌ Erro ao buscar no YouTube.")
        return
    queues[guild_id].append((url, title))
    await ctx.send(f"➕ Adicionado à fila: **{title}** (posição {len(queues[guild_id])})")
    # if not playing, start
    vc = ctx.voice_client
    if not vc.is_playing():
        await play_next(ctx)

@bot.command(name="pular")
async def cmd_pular(ctx):
    vc = ctx.voice_client
    if vc and vc.is_playing():
        vc.stop()
        await ctx.send("⏭️ Música pulada!")
    else:
        await ctx.send("❌ Nenhuma música tocando.")

@bot.command(name="parar")
async def cmd_parar(ctx):
    vc = ctx.voice_client
    if vc:
        vc.stop()
        queues.pop(ctx.guild.id, None)
        await vc.disconnect()
        await ctx.send("⏹️ Música parada e fila limpa!")
    else:
        await ctx.send("❌ Não estou tocando nada.")

@bot.command(name="pause")
async def cmd_pause(ctx):
    vc = ctx.voice_client
    if vc and vc.is_playing():
        vc.pause()
        await ctx.send("⏸️ Música pausada!")
    else:
        await ctx.send("❌ Nenhuma música tocando.")

@bot.command(name="resume")
async def cmd_resume(ctx):
    vc = ctx.voice_client
    if vc and vc.is_paused():
        vc.resume()
        await ctx.send("▶️ Música retomada!")
    else:
        await ctx.send("❌ Nenhuma música pausada.")

@bot.command(name="volume")
async def cmd_volume(ctx, val: int):
    if val < 0 or val > 200:
        await ctx.send("⚠️ Valor inválido. Use 0–200 (100 = normal).")
        return
    volume[ctx.guild.id] = max(0.0, min(2.0, val / 100.0))
    await ctx.send(f"🔊 Volume ajustado para **{val}%**.")

@bot.command(name="fila")
async def cmd_fila(ctx):
    guild_id = ctx.guild.id
    if guild_id in queues and queues[guild_id]:
        lines = [f"{i+1}. {t}" for i, (_, t) in enumerate(queues[guild_id])]
        await ctx.send("📜 Fila atual:\n" + "\n".join(lines))
    else:
        await ctx.send("✅ A fila está vazia.")

# ====== RUN ======
if __name__ == '__main__':
    if TOKEN is None:
        print("ERROR: DISCORD_TOKEN environment variable not set.")
    else:
        bot.run(TOKEN)
