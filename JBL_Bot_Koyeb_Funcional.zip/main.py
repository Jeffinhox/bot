import os
import asyncio
import discord
from discord.ext import commands
import yt_dlp

TOKEN = os.getenv("DISCORD_TOKEN")
PREFIX = "!"
intents = discord.Intents.default()
intents.message_content = True
intents.voice_states = True

bot = commands.Bot(command_prefix=PREFIX, intents=intents, help_command=None)

queues = {}
volumes = {}

ydl_opts = {
    "format": "bestaudio/best",
    "quiet": True,
    "default_search": "ytsearch",
    "noplaylist": True,
}

ffmpeg_opts = "-vn"
ffmpeg_before_opts = "-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5"

ytdl = yt_dlp.YoutubeDL(ydl_opts)

def yt_search(query):
    info = ytdl.extract_info(query, download=False)
    if "entries" in info:
        info = info["entries"][0]
    return info["url"], info.get("title", "Unknown title")

async def ensure_voice(ctx):
    if ctx.voice_client is None:
        if ctx.author.voice and ctx.author.voice.channel:
            await ctx.author.voice.channel.connect()
        else:
            await ctx.send("❌ Entre em um canal de voz primeiro.")
            return False
    return True

def get_volume(guild_id):
    return volumes.get(guild_id, 0.5)

async def play_next(ctx):
    guild_id = ctx.guild.id
    vc = ctx.voice_client
    if not vc or not vc.is_connected():
        return
    if guild_id not in queues or len(queues[guild_id]) == 0:
        try:
            await vc.disconnect()
        except:
            pass
        await ctx.send("✅ Fila finalizada. Sai do canal de voz.")
        return

    url, title = queues[guild_id].pop(0)
    source = discord.FFmpegPCMAudio(url, before_options=ffmpeg_before_opts, options=ffmpeg_opts)
    player = discord.PCMVolumeTransformer(source, volume=get_volume(guild_id))
    def after_play(err):
        fut = asyncio.run_coroutine_threadsafe(play_next(ctx), bot.loop)
        try:
            fut.result()
        except Exception:
            pass
    vc.play(player, after=after_play)
    await ctx.send(f"▶️ Tocando agora: **{title}**")

@bot.event
async def on_ready():
    print(f"✅ JBL Bot online como {bot.user}")

@bot.command(name="tocar")
async def tocar(ctx, *, query: str):
    if not await ensure_voice(ctx):
        return
    guild_id = ctx.guild.id
    if guild_id not in queues:
        queues[guild_id] = []
    await ctx.send(f"🔎 Procurando: **{query}**")
    try:
        url, title = yt_search(query)
    except:
        await ctx.send("❌ Erro ao buscar música.")
        return
    queues[guild_id].append((url, title))
    await ctx.send(f"➕ Adicionado à fila: **{title}** (posição {len(queues[guild_id])})")
    vc = ctx.voice_client
    if not vc.is_playing():
        await play_next(ctx)

@bot.command(name="pular")
async def pular(ctx):
    vc = ctx.voice_client
    if vc and vc.is_playing():
        vc.stop()
        await ctx.send("⏭️ Música pulada!")
    else:
        await ctx.send("❌ Nenhuma música tocando.")

@bot.command(name="parar")
async def parar(ctx):
    vc = ctx.voice_client
    if vc:
        vc.stop()
        queues.pop(ctx.guild.id, None)
        await vc.disconnect()
        await ctx.send("⏹️ Música parada e fila limpa!")
    else:
        await ctx.send("❌ Não estou tocando nada.")

@bot.command(name="volume")
async def volume_cmd(ctx, val: int):
    if val < 0 or val > 200:
        await ctx.send("⚠️ Use valor de 0–200 (100 = normal).")
        return
    volumes[ctx.guild.id] = max(0.0, min(2.0, val / 100.0))
    await ctx.send(f"🔊 Volume ajustado para **{val}%**.")

@bot.command(name="fila")
async def fila(ctx):
    guild_id = ctx.guild.id
    if guild_id in queues and queues[guild_id]:
        lines = [f"{i+1}. {t}" for i, (_, t) in enumerate(queues[guild_id])]
        await ctx.send("📜 Fila atual:\n" + "\n".join(lines))
    else:
        await ctx.send("✅ A fila está vazia.")

if __name__ == "__main__":
    if TOKEN is None:
        print("ERROR: DISCORD_TOKEN not set")
    else:
        bot.run(TOKEN)
